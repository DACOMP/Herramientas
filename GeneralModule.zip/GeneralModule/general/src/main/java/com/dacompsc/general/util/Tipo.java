package com.dacompsc.general.util;

/**
 * @author isaaclopez
 *
 */
public enum Tipo {
  /**
   *
   */
  DEBUG,/**
   *
   */
  @Deprecated
  ERROR,/**
   *
   */
  INFO,/**
   *
   */
  VERBOSE,/**
   *
   */
  WARN};
