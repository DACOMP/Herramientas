package com.dacompsc.general;

import android.os.Build;

public class AplicationGeneral {

    public final static boolean DEBUG = BuildConfig.DEBUG;
}
